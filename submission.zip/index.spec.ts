
import { CalculatorModel } from './index';

describe('week6-structural-behavioral-DP', (): void => {

  describe('CalculatorModel', (): void => {

    it('CalculatorModel exists', (): void => {

      expect(CalculatorModel).toBeDefined();

    });

  });

});
